import { useState } from 'react';
import CityCompanySelector from './components/CityCompanySelector';
import ReceivableSummary from './components/ReceivableSummary';
import axios from 'axios';
import { toast } from 'react-toastify';

const AgingReceivableSummary = () => {
  const [selectedCity, setSelectedCity] = useState(null);
  const [selectedCompany, setSelectedCompany] = useState(null);
  const [companies, setCompanies] = useState([]);
  const [allSelectedCompanies, setAllSelectedCompanies] = useState([]);

  // Handle city change
  const handleCityChange = (city) => {
    setSelectedCity(city);
    setSelectedCompany(null);
    setCompanies([]);
  };

  // Select All button
  const handleSelectAll = async () => {
    if (!selectedCity) return;

    try {
      const res = await axios.get(`http://localhost:5000/api/aging-companies?city=${selectedCity}`);
      const newCompanies = res.data.filter(
        (c) => !allSelectedCompanies.includes(c)
      );
      setCompanies(res.data);
      setAllSelectedCompanies((prev) => [...prev, ...newCompanies]);
    } catch (err) {
      toast.error('Error fetching companies:', err);
    }
  };

  // When individual company is selected
  const handleSelectCompany = (company) => {
    if (!allSelectedCompanies.includes(company)) {
      setAllSelectedCompanies((prev) => [...prev, company]);
    }
    setSelectedCompany(company);
  };

  return (
    <div className="p-4">
      {/* City + Company Selector */}
      <CityCompanySelector
        selectedCity={selectedCity}
        setSelectedCity={handleCityChange}
        selectedCompany={selectedCompany}
        setSelectedCompany={handleSelectCompany}
      />

      {/* Select All Button */}
      {selectedCity && (
        <button
          onClick={handleSelectAll}
          style={{ backgroundColor: '#292E49' }}
          className="mb-4 px-4 py-2 text-white rounded hover:bg-blue-700"
        >
          Select All Companies
        </button>
      )}

      {/* Render single combined table for all selected companies */}
      {allSelectedCompanies.length > 0 && (
        <ReceivableSummary companies={allSelectedCompanies} city={selectedCity} />
      )}
    </div>
  );
};

export default AgingReceivableSummary;
