import { useEffect, useState, useRef } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';

const ReceivableSummary = ({ companies, city }) => {
  const [summaries, setSummaries] = useState([]);
  const fetchedCompaniesRef = useRef(new Set());

  useEffect(() => {
    if (!companies || companies.length === 0) return;

    let isMounted = true;

    const fetchNext = async (index) => {
      if (index >= companies.length || !isMounted) return;

      const company = companies[index];
      if (fetchedCompaniesRef.current.has(company)) {
        fetchNext(index + 1);
        return;
      }

      try {
        const res = await axios.get(
          `http://localhost:5000/api/aging-report-summary?description=${encodeURIComponent(company)}`
        );
        const data = res.data;

        const today = new Date();
        let crSum = 0;
        let showRemaining = false;
        let cumulativeBalance = 0;
        const buckets = {
          '1-15': 0, '16-30': 0, '31-45': 0,
          '46-60': 0, '61-75': 0, '76-90': 0, '91+': 0,
        };

        data.forEach(row => {
          if (row.VCr) crSum += row.VCr;
        });

        data.forEach(row => {
          const invAmount = row.VDr || 0;
          const payment = row.VCr || 0;

          if (payment) return;

          if (!showRemaining) {
            if (crSum >= invAmount) {
              crSum -= invAmount;
              return;
            } else {
              showRemaining = true;
            }
          }

          const balance = invAmount - crSum;
          crSum = 0;
          cumulativeBalance += balance;

          const days = Math.floor((today - new Date(row.Vdate)) / (1000 * 60 * 60 * 24));

          if (days <= 15) buckets['1-15'] += balance;
          else if (days <= 30) buckets['16-30'] += balance;
          else if (days <= 45) buckets['31-45'] += balance;
          else if (days <= 60) buckets['46-60'] += balance;
          else if (days <= 75) buckets['61-75'] += balance;
          else if (days <= 90) buckets['76-90'] += balance;
          else buckets['91+'] += balance;
        });

        const summary = {
          company,
          code: data[0]?.VCode || 'N/A',
          ...buckets,
          Balance: cumulativeBalance,
        };

        if (isMounted) {
          setSummaries(prev => [...prev, summary]);
          fetchedCompaniesRef.current.add(company);
          fetchNext(index + 1);
        }

      } catch (err) {
        toast.error(`Error fetching summary for ${company}:`, err);
        fetchNext(index + 1);
      }
    };

    fetchNext(0); // start with the first company

    return () => {
      isMounted = false; // cleanup if component unmounts
    };

  }, [companies, city]);

  if (summaries.length === 0) {
    return <p className="text-gray-600 mt-6">No summary found.</p>;
  }

  return (
    <div className="mt-6">
      {/* Print Button */}
      <div className="mb-4 flex justify-end no-print">
        <button
          onClick={() => window.print()}
          style={{ backgroundColor: '#292E49' }}
          className="text-white px-4 py-2 rounded w-full sm:w-auto flex items-center justify-center"
        >
          <span className="mr-1">Print</span> 🖨️
        </button>
      </div>

      {/* Desktop Table */}
      <div className="hidden sm:block overflow-x-auto print-area">
        <table className="min-w-full text-sm text-center border">
          <thead className="bg-gray-100">
            <tr>
              <th className="border p-2">Code</th>
              <th className="border p-2">Party Name</th>
              <th className="border p-2">1–15</th>
              <th className="border p-2">16–30</th>
              <th className="border p-2">31–45</th>
              <th className="border p-2">46–60</th>
              <th className="border p-2">61–75</th>
              <th className="border p-2">76–90</th>
              <th className="border p-2">91+</th>
              <th className="border p-2">Balance</th>
            </tr>
          </thead>
          <tbody>
            {summaries.map((summary, idx) => (
              <tr key={idx} className="font-medium">
                <td className="border p-2">{summary.code}</td>
                <td className="border p-2">{summary.company}</td>
                <td className="border p-2">{summary['1-15'].toLocaleString()}</td>
                <td className="border p-2">{summary['16-30'].toLocaleString()}</td>
                <td className="border p-2">{summary['31-45'].toLocaleString()}</td>
                <td className="border p-2">{summary['46-60'].toLocaleString()}</td>
                <td className="border p-2">{summary['61-75'].toLocaleString()}</td>
                <td className="border p-2">{summary['76-90'].toLocaleString()}</td>
                <td className="border p-2">{summary['91+'].toLocaleString()}</td>
                <td className="border p-2 font-semibold">{summary.Balance.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Card Layout */}
      <div className="sm:hidden space-y-4">
        {summaries.map((summary, idx) => (
          <div
            key={idx}
            className="border rounded-lg shadow-md p-4 bg-white"
          >
            <p><strong>Code:</strong> {summary.code}</p>
            <p><strong>Party Name:</strong> {summary.company}</p>
            <p><strong>1–15:</strong> {summary['1-15'].toLocaleString()}</p>
            <p><strong>16–30:</strong> {summary['16-30'].toLocaleString()}</p>
            <p><strong>31–45:</strong> {summary['31-45'].toLocaleString()}</p>
            <p><strong>46–60:</strong> {summary['46-60'].toLocaleString()}</p>
            <p><strong>61–75:</strong> {summary['61-75'].toLocaleString()}</p>
            <p><strong>76–90:</strong> {summary['76-90'].toLocaleString()}</p>
            <p><strong>91+:</strong> {summary['91+'].toLocaleString()}</p>
            <p className="font-bold"><strong>Balance:</strong> {summary.Balance.toLocaleString()}</p>
          </div>
        ))}
      </div>

      {/* Print-specific CSS */}
      <style jsx>{`
      @media print {
        .no-print {
          display: none !important;
        }
        .print-area {
          display: block !important;
        }
      }
    `}</style>
    </div>
  );
};

export default ReceivableSummary;
