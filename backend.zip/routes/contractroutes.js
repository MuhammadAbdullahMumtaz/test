const express = require('express');
const router = express.Router();
const {
  fetchContracts,
  fetchContractById,
  saveRemarks
} = require('../controllers/contractController');

router.get('/', fetchContracts);
router.get('/:id', fetchContractById);
router.post('/save-remarks', saveRemarks);

module.exports = router;
