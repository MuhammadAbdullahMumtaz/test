const express = require('express');
const router = express.Router();
const { getAgingReport, fetchCities, fetchCompanies, fetchAllCompanies, getAgingReportSummary } = require("../controllers/agingcontroller")

router.get('/aging-report', getAgingReport);
router.get('/aging-cities', fetchCities);
router.get('/aging-companies', fetchCompanies);
router.get('/aging-all-companies', fetchAllCompanies);
router.get('/aging-report-summary', getAgingReportSummary);

module.exports = router;

