const express = require('express');
const router = express.Router();
const { fetchDescriptions, fetchFilteredLedger, getOpeningBalance } = require('../controllers/ledgercontroller');

router.get('/ledger/descriptions', fetchDescriptions); 
router.get('/ledger/filter', fetchFilteredLedger);
router.get('/ledger/opening-balance', getOpeningBalance);

module.exports = router;
