const { sql, poolPromise } = require('../config/db');

async function getAllPendingContracts() {
  const pool = await poolPromise;
  const result = await pool
    .request()
    .query("SELECT DISTINCT Cont_No AS id FROM Yarn_Contract WHERE Cont_Status = 'Not Approved'");
  return result.recordset;
}

async function getContractById(id) {
  const pool = await poolPromise;
  const result = await pool
    .request()
    .input('Cont_No', sql.VarChar, id)
    .query('SELECT * FROM Yarn_Contract WHERE Cont_No = @Cont_No');
  return result.recordset;
}

async function updateContractRemarks(contractId, remarks) {
  const pool = await poolPromise;
  return pool.request()
    .input('Cont_No', sql.VarChar, contractId)
    .input('Remarks', sql.NVarChar, remarks)
    .input('Cont_Status', sql.VarChar, 'Approved')
    .query(`
      UPDATE Yarn_Contract
      SET Remarks = @Remarks,
          Cont_Status = @Cont_Status
      WHERE Cont_No = @Cont_No
    `);
}

module.exports = {
  getAllPendingContracts,
  getContractById,
  updateContractRemarks
};
