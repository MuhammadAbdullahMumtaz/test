require('dotenv').config();

// const sqlConfig = {
//   server: process.env.LOCAL_DB_SERVER,
//   database: process.env.LOCAL_DB_DATABASE,
//   driver: 'msnodesqlv8',
//   options: {
//     trustedConnection: true,
//     trustServerCertificate: true,
//   }
// };




const sqlConfig = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER,
  port: process.env.DB_PORT,
  database: process.env.DB_DATABASE,
  options: {
    encrypt: false,
    trustServerCertificate: true,
  }
};

module.exports = sqlConfig;