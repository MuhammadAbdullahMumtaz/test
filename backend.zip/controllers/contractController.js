const {
  getAllPendingContracts,
  getContractById,
  updateContractRemarks
} = require('../models/contractmodel');

const fetchContracts = async (req, res) => {
  try {
    const contracts = await getAllPendingContracts();
    res.status(200).json(contracts);
  } catch (err) {
    console.error('Error fetching contracts:', err);
    res.status(500).json({ message: 'Failed to fetch contracts' });
  }
};

const fetchContractById = async (req, res) => {
  try {
    const data = await getContractById(req.params.id);
    if (data.length === 0) {
      res.status(404).json({ message: 'Contract not found' });
    } else {
      res.status(200).json(data);
    }
  } catch (err) {
    console.error('Error fetching contract details:', err);
    res.status(500).json({ message: 'Failed to fetch contract details' });
  }
};

const saveRemarks = async (req, res) => {
  const { contractId, mergedRemark, password } = req.body;

  if (!contractId || !mergedRemark) return res.status(400).json({ message: 'Invalid input' });
  if (password !== process.env.APPROVAL_PASSWORD) return res.status(403).json({ message: 'Incorrect approval password' });

  try {
    const result = await updateContractRemarks(contractId, mergedRemark);
    if (result.rowsAffected[0] > 0) {
      res.status(200).json({ message: 'Remarks updated successfully' });
    } else {
      res.status(404).json({ message: 'Contract not found' });
    }
  } catch (err) {
    console.error('Error saving remarks:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
  fetchContracts,
  fetchContractById,
  saveRemarks
};
