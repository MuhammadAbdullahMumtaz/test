const { poolPromise } = require('../config/db');

const  getAgingReport = async (req, res) => {
    const { description } = req.query;

    try {
        const pool = await poolPromise;

        const result = await pool
            .request()
            .input('description', description)
            .query(`
                SELECT VNo, Vdate, VNarr, VDr, VCr
                FROM VW_PartyLedger
                WHERE VCode = (
                    SELECT TOP 1 Acc_Code 
                    FROM Chart_Accounts 
                    WHERE Acc_Description = @description
                )
                ORDER BY Vdate ASC
            `);

        res.status(200).json(result.recordset);
    } catch (error) {
        console.error('Error fetching aging report:', error);
        res.status(500).json({ message: 'Failed to fetch aging report' });
    }
};

const fetchCities = async (req, res) => {
    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .query("SELECT DISTINCT P_City FROM Vw_ChartOfAccount WHERE P_City IS NOT NULL AND P_City <> ''");

        const cities = result.recordset.map(row => row.P_City);
        res.status(200).json(cities);
    } catch (error) {
        console.error('Error fetching cities:', error);
        res.status(500).json({ message: 'Failed to fetch cities', error: error.message });
    }
};

const fetchCompanies = async (req, res) => {
    const city = req.query.city;
    try {
        const pool = await poolPromise;
        const result = await pool
            .request()
            .input('city', city)
            .query(`
                SELECT Acc_Description
                FROM Vw_ChartOfAccount
                WHERE P_City = @city
            `);

        res.json(result.recordset.map(row => row.Acc_Description));
    } catch (err) {
        console.error('Error fetching companies:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};

const  getAgingReportSummary = async (req, res) => {
    const { description } = req.query;

    try {
        const pool = await poolPromise;

        const result = await pool
            .request()
            .input('description', description)
            .query(`
                SELECT VCode, Vdate, VDr, VCr
                FROM VW_PartyLedger
                WHERE VCode = (
                    SELECT TOP 1 Acc_Code 
                    FROM Chart_Accounts 
                    WHERE Acc_Description = @description
                )
                ORDER BY Vdate
            `);

        res.status(200).json(result.recordset);
    } catch (error) {
        console.error('Error fetching aging report:', error);
        res.status(500).json({ message: 'Failed to fetch aging report' });
    }
};

module.exports = {
    getAgingReport,
    fetchCities,
    fetchCompanies,
    getAgingReportSummary,
};