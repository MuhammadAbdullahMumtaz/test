const { poolPromise } = require('../config/db');

const fetchDescriptions = async (req, res) => {
    try {
        const search = req.query.search || '';
        const pool = await poolPromise;
        const result = await pool
            .request()
            .input('search', `%${search}%`)
            .query("SELECT DISTINCT Acc_Description FROM Chart_Accounts WHERE Acc_Description LIKE @search AND Acc_Description IS NOT NULL");

        res.status(200).json(result.recordset);
    } catch (err) {
        console.error('Error fetching descriptions:', err);
        res.status(500).json({ message: 'Failed to fetch account descriptions' });
    }
};


const fetchFilteredLedger = async (req, res) => {
    const { search, from, to } = req.query;

    if (!search || !from || !to) {
        return res.status(400).json({ message: 'Missing search, from, or to parameter' });
    }

    try {
        const pool = await poolPromise;

        const result = await pool.request()
            .input('search', search)
            .input('from', from)
            .input('to', to)
            .query(`
                SELECT * FROM VW_PartyLedger 
                WHERE Vdate >= @from   AND Vdate <= @to 
                AND VCode = (
                SELECT TOP 1 Acc_Code FROM Chart_Accounts 
                WHERE Acc_Description = @search
                )
                ORDER BY Vdate ASC
            `);

        res.status(200).json(result.recordset);
    } catch (error) {
        console.error('Error fetching filtered ledger data:', error);
        res.status(500).json({ message: 'Failed to fetch filtered ledger data' });
    }
};

const getOpeningBalance = async (req, res) => {
    const { search, from } = req.query;

    if (!search || !from) {
        return res.status(400).json({ message: "Missing 'search' or 'from' query parameters." });
    }

    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .input('search', search)
            .input('fromDate', from)
            .query(`
                SELECT ISNULL(SUM(ISNULL(VDr, 0)), 0) - ISNULL(SUM(ISNULL(VCr, 0)), 0) AS openingBalance FROM VW_PartyLedger
                WHERE Vdate < @fromDate 
                AND VCode = (
                SELECT TOP 1 Acc_Code FROM Chart_Accounts 
                WHERE Acc_Description = @search
                )
            `);

        const openingBalance = result.recordset[0].openingBalance || 0;

        res.json({ openingBalance });
    } catch (error) {
        console.error('Error fetching opening balance:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};


module.exports = {
    fetchDescriptions,
    fetchFilteredLedger,
    getOpeningBalance,
};
