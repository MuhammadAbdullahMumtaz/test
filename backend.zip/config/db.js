//  /msnodesqlv8
// "msnodesqlv8": "^4.5.0",

const sql = require('mssql');
const config = require('../config');

const poolPromise = new sql.ConnectionPool(config)
  .connect()
  .then(pool => {
    console.log('✅ MSSQL Connected');
    return pool;
  })
  .catch(err => {
    console.error('❌ MSSQL Connection Failed:', err);
  });

module.exports = {
  sql,
  poolPromise
};
