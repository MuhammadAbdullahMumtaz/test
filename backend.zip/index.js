require('dotenv').config();
const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/authroutes');
const contractRoutes = require('./routes/contractroutes');
const ledgerRoutes = require('./routes/ledgerroutes');
const agingRoutes = require('./routes/agingroute');

const app = express();
const PORT = process.env.PORT;

// app.use(cors({ origin: 'https://bariz.pk' }));
app.use(cors({ origin: 'http://localhost:5173' }));
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/demand-contracts', contractRoutes);
app.use('/api', ledgerRoutes);
app.use('/api', agingRoutes);

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
